"""Image service: loads images and extracts image / layout features with OpenCV."""
import os

import cv2
import numpy as np
from PIL import Image, ImageOps

from config import Config


class ImageProcessingError(Exception):
    """Raised when an image is corrupt or cannot be processed."""


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------
def load_image(path):
    """Load an image as an OpenCV (BGR) array. Fixes rotation and transparency."""
    try:
        with Image.open(path) as pil:
            pil = ImageOps.exif_transpose(pil)
            if pil.mode in ("RGBA", "LA", "P"):
                pil = pil.convert("RGBA")
                background = Image.new("RGBA", pil.size, (255, 255, 255, 255))
                background.alpha_composite(pil)
                pil = background
            rgb = np.array(pil.convert("RGB"))
    except Exception as exc:
        raise ImageProcessingError(
            "The image could not be opened. The file may be corrupt."
        ) from exc

    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    h, w = bgr.shape[:2]
    if h < 50 or w < 50:
        raise ImageProcessingError("The image is too small to analyse (minimum 50x50 pixels).")
    longest = max(h, w)
    if longest > Config.MAX_IMAGE_SIDE:  # resize step
        scale = Config.MAX_IMAGE_SIDE / longest
        bgr = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    return bgr


def _normalised_gray(image_bgr, target=1000):
    """Gray image scaled so its longest side is `target` px (keeps features comparable)."""
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    scale = target / float(max(gray.shape))
    interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
    return cv2.resize(gray, None, fx=scale, fy=scale, interpolation=interp)


# --------------------------------------------------------------------------
# Pre-processing pipeline (resize -> gray -> denoise -> contrast -> threshold -> edges)
# --------------------------------------------------------------------------
def preprocess(image_bgr):
    gray = _normalised_gray(image_bgr)
    denoised = cv2.GaussianBlur(gray, (3, 3), 0)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(denoised)
    _, otsu = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    edges = cv2.Canny(denoised, 80, 180)
    return {"gray": gray, "denoised": denoised, "enhanced": enhanced,
            "ink_mask": otsu, "edges": edges}


# --------------------------------------------------------------------------
# Layout analysis
# --------------------------------------------------------------------------
def _remove_borders(ink_mask):
    """Certificates often have a decorative frame. Remove long straight lines so the
    frame does not swallow every other region."""
    h, w = ink_mask.shape
    horizontal = cv2.morphologyEx(ink_mask, cv2.MORPH_OPEN,
                                  cv2.getStructuringElement(cv2.MORPH_RECT, (max(w // 6, 20), 1)))
    vertical = cv2.morphologyEx(ink_mask, cv2.MORPH_OPEN,
                                cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(h // 6, 20))))
    lines = cv2.dilate(cv2.bitwise_or(horizontal, vertical), np.ones((5, 5), np.uint8))
    cleaned = cv2.bitwise_and(ink_mask, cv2.bitwise_not(lines))
    m = int(0.012 * max(h, w))          # also ignore a thin margin around the page
    cleaned[:m, :] = 0
    cleaned[-m:, :] = 0
    cleaned[:, :m] = 0
    cleaned[:, -m:] = 0
    return cleaned


def _find_text_regions(ink_mask):
    """Merge nearby ink pixels into text blocks and return their bounding boxes."""
    h, w = ink_mask.shape
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 7))
    merged = cv2.dilate(ink_mask, kernel, iterations=1)
    contours, _ = cv2.findContours(merged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    min_area = 0.0004 * w * h
    boxes = []
    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        if bw * bh >= min_area and bw > 20 and bh > 8 and not (bw > 0.97 * w and bh > 0.97 * h):
            boxes.append((x, y, bw, bh))
    return boxes


def _find_logo_region(ink_mask):
    """Heuristic: a compact, dense blob in the top 30% of the page."""
    h, w = ink_mask.shape
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    blobs = cv2.dilate(ink_mask, kernel, iterations=1)
    contours, _ = cv2.findContours(blobs, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        area_ratio = (bw * bh) / float(w * h)
        aspect = bw / float(bh)
        if y + bh > 0.30 * h or not (0.005 <= area_ratio <= 0.10) or not (0.5 <= aspect <= 2.8):
            continue
        fill = cv2.countNonZero(ink_mask[y:y + bh, x:x + bw]) / float(bw * bh)
        if fill >= 0.15 and (best is None or bw * bh > best[2] * best[3]):
            best = (x, y, bw, bh)
    return best


def _find_signature_region(ink_mask):
    """Heuristic: a wide, sparse, scribble-like area in the bottom 35% of the page."""
    h, w = ink_mask.shape
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 9))
    blobs = cv2.dilate(ink_mask, kernel, iterations=1)
    contours, _ = cv2.findContours(blobs, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    best = None
    for c in contours:
        x, y, bw, bh = cv2.boundingRect(c)
        area_ratio = (bw * bh) / float(w * h)
        aspect = bw / float(bh)
        if y < 0.65 * h or not (0.002 <= area_ratio <= 0.04) or not (1.8 <= aspect <= 8):
            continue
        fill = cv2.countNonZero(ink_mask[y:y + bh, x:x + bw]) / float(bw * bh)
        if 0.04 <= fill <= 0.35 and (best is None or bw * bh > best[2] * best[3]):
            best = (x, y, bw, bh)
    return best


# --------------------------------------------------------------------------
# Main entry point
# --------------------------------------------------------------------------
def analyze_image(image_bgr):
    """Return image features, layout information and processed images."""
    prep = preprocess(image_bgr)
    gray, edges = prep["gray"], prep["edges"]
    ink = _remove_borders(prep["ink_mask"])
    h_img, w_img = image_bgr.shape[:2]

    residual = gray.astype(np.float32) - cv2.GaussianBlur(gray, (5, 5), 0).astype(np.float32)
    hsv = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2HSV)
    mean_b, mean_g, mean_r = [float(v) for v in image_bgr.reshape(-1, 3).mean(axis=0)]

    boxes = _find_text_regions(ink)
    text_area = sum(bw * bh for _, _, bw, bh in boxes)
    logo = _find_logo_region(ink)
    signature = _find_signature_region(ink)

    features = {
        "width": int(w_img),
        "height": int(h_img),
        "aspect_ratio": round(w_img / float(h_img), 4),
        "brightness": round(float(gray.mean()), 3),
        "contrast": round(float(gray.std()), 3),
        "edge_density": round(float(np.count_nonzero(edges)) / edges.size, 5),
        "blur_score": round(float(cv2.Laplacian(gray, cv2.CV_64F).var()), 3),
        "noise_level": round(float(np.median(np.abs(residual)) / 0.6745), 3),
        "color_saturation": round(float(hsv[..., 1].mean()), 3),
        "text_density": round(min(1.0, text_area / float(gray.size)), 4),
        "region_count": int(len(boxes)),
        "has_logo_region": int(logo is not None),
        "has_signature_region": int(signature is not None),
    }
    color_stats = {"mean_red": round(mean_r, 1), "mean_green": round(mean_g, 1),
                   "mean_blue": round(mean_b, 1)}

    # Error Level Analysis (ELA)
    ela_res = compute_ela(image_bgr)

    return {"features": features, "color_stats": color_stats, "boxes": boxes,
            "logo": logo, "signature": signature, "prep": prep, "ela": ela_res}


# --------------------------------------------------------------------------
# Error Level Analysis (ELA) for Tamper Detection
# --------------------------------------------------------------------------
def compute_ela(image_bgr, quality=90, scale=15):
    """
    Error Level Analysis (ELA):
    Re-compresses an image at a specific JPEG quality and computes the absolute
    pixel difference. Modified or spliced regions compress at a distinct error rate.
    """
    import io
    rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
    pil_img = Image.fromarray(rgb)

    buffer = io.BytesIO()
    pil_img.save(buffer, format="JPEG", quality=quality)
    buffer.seek(0)

    recompressed = np.array(Image.open(buffer).convert("RGB"))
    diff = cv2.absdiff(rgb, recompressed)
    ela_enhanced = np.clip(diff.astype(np.float32) * scale, 0, 255).astype(np.uint8)

    ela_mean = float(diff.mean())
    ela_std = float(diff.std())
    ela_max = float(diff.max())
    ela_bgr = cv2.cvtColor(ela_enhanced, cv2.COLOR_RGB2BGR)

    tamper_score = round(min(100.0, (ela_mean * 7.5) + (ela_std * 4.5)), 1)

    return {
        "ela_image": ela_bgr,
        "ela_mean": round(ela_mean, 3),
        "ela_std": round(ela_std, 3),
        "ela_max": round(ela_max, 3),
        "tamper_score": tamper_score,
    }


# --------------------------------------------------------------------------
# Saving visual outputs for the result page
# --------------------------------------------------------------------------
def _write_png(path, image):
    ok, buf = cv2.imencode(".png", image)
    if not ok:
        raise ImageProcessingError("Could not save the processed image.")
    buf.tofile(path)


def save_edge_map(info, path):
    _write_png(path, 255 - info["prep"]["edges"])  # dark edges on white


def save_ela_map(info, path):
    _write_png(path, info["ela"]["ela_image"])


def save_layout_overlay(info, path):
    """Draw detected regions on the grayscale page (blue = text, green = logo, orange = signature)."""
    canvas = cv2.cvtColor(info["prep"]["gray"], cv2.COLOR_GRAY2BGR)
    for x, y, w, h in info["boxes"]:
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (255, 120, 30), 2)       # blue (BGR)
    if info["logo"]:
        x, y, w, h = info["logo"]
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (80, 170, 20), 4)        # green
    if info["signature"]:
        x, y, w, h = info["signature"]
        cv2.rectangle(canvas, (x, y), (x + w, y + h), (30, 140, 245), 4)       # orange
    _write_png(path, canvas)
