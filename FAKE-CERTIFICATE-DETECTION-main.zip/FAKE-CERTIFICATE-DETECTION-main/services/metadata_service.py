"""Metadata service: reads basic file metadata (supporting evidence only)."""
import os
import re
from datetime import datetime

from PIL import Image
from PIL.ExifTags import TAGS

DISCLAIMER = ("Metadata can be missing (screenshots, messaging apps and online converters remove it) "
              "or edited on purpose. It is only supporting information and never proof either way.")

_EDITING_TOOLS = ["photoshop", "gimp", "canva", "illustrator", "coreldraw", "affinity",
                  "pixlr", "paint", "inkscape", "figma", "snapseed", "lightroom"]


def _human_size(num_bytes):
    for unit in ("B", "KB", "MB"):
        if num_bytes < 1024 or unit == "MB":
            return f"{num_bytes:.0f} {unit}" if unit == "B" else f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0


def _parse_pdf_date(value):
    """Convert 'D:20240131120000+05'30'' into '2024-01-31 12:00:00'."""
    m = re.match(r"D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?", value or "")
    if not m:
        return value or ""
    parts = [int(g) if g else d for g, d in zip(m.groups(), [0, 1, 1, 0, 0, 0])]
    try:
        return datetime(*parts).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return value


def get_metadata(path, ext, original_name, image_size, pdf_info=None):
    items = {
        "File name": original_name,
        "File type": ext.upper(),
        "File size": _human_size(os.path.getsize(path)),
    }
    notes, software, has_metadata, modified_after = [], None, False, False

    if ext in ("jpg", "jpeg", "png"):
        items["Image dimensions"] = f"{image_size[0]} x {image_size[1]} px"
        try:
            with Image.open(path) as img:
                items["Image format"] = img.format or ext.upper()
                items["Colour mode"] = img.mode
                exif = img.getexif()
                for tag_id, value in exif.items():
                    name = TAGS.get(tag_id, str(tag_id))
                    if name in ("Make", "Model", "Software", "DateTime"):
                        items[f"EXIF {name}"] = str(value)[:80]
                        has_metadata = True
                        if name == "Software":
                            software = str(value)
        except Exception:
            notes.append("Image metadata could not be read.")
        if not has_metadata:
            notes.append("No EXIF metadata found (common for screenshots and shared images).")

    elif ext == "pdf" and pdf_info:
        meta = pdf_info.get("metadata", {})
        items["Pages"] = f"{pdf_info['page_count']} (analysed: {pdf_info['pages_analysed']})"
        items["Rendered page size"] = f"{image_size[0]} x {image_size[1]} px"
        items["Selectable text"] = "Yes" if pdf_info["has_text_layer"] else "No (scanned / image PDF)"
        items["Embedded images"] = str(pdf_info["embedded_images"])
        if pdf_info.get("pdf_format"):
            items["PDF version"] = pdf_info["pdf_format"]
        for key, label in [("title", "Title"), ("author", "Author"), ("creator", "Creator"),
                           ("producer", "Producer")]:
            if meta.get(key):
                items[label] = meta[key][:80]
                has_metadata = True
        created = _parse_pdf_date(meta.get("creationDate", ""))
        modified = _parse_pdf_date(meta.get("modDate", ""))
        if created:
            items["Created"] = created
            has_metadata = True
        if modified:
            items["Modified"] = modified
            has_metadata = True
        if created and modified and modified > created:
            modified_after = True
            notes.append("The PDF was modified after it was created (normal for many documents).")
        software = meta.get("creator") or meta.get("producer") or None
        if not has_metadata:
            notes.append("No PDF metadata found.")

    editing_tool = None
    if software:
        for tool in _EDITING_TOOLS:
            if tool in software.lower():
                editing_tool = software
                notes.append(f"Created or edited with '{software}'. Many genuine certificates are "
                             "designed in such tools, so this is informational only.")
                break

    return {"items": items, "notes": notes, "editing_tool": editing_tool,
            "has_metadata": has_metadata, "modified_after_creation": modified_after,
            "disclaimer": DISCLAIMER}
