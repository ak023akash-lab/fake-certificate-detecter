# dataset/

This folder holds the training data.

| File | Created by | Meaning |
|------|-----------|---------|
| `certificate_features.csv` | `python ml/dataset_generator.py` | **Synthetic demo dataset.** Only numbers (24 features + `label`). No certificates, images or forged documents. |
| `real/genuine/` | you | (optional) certificates verified as genuine, used only with permission |
| `real/suspicious/` | you | (optional) documents confirmed as fake or tampered, used only with permission |
| `real_features.csv` | `python ml/build_real_dataset.py` | features extracted from your own labelled files |

Labels: `0 = Suspicious`, `1 = Genuine`.

The synthetic dataset only demonstrates the machine-learning pipeline. For any real use, replace it with a properly labelled, permission-based dataset (see the main README, section "How to replace the demo dataset").
