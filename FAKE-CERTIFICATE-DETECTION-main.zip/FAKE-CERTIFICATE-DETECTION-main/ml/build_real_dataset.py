"""
OPTIONAL: build a real feature dataset from your own labelled files.

Folder layout (you create it, only with documents you are allowed to use):
    dataset/real/genuine/      <- certificates verified as genuine
    dataset/real/suspicious/   <- certificates confirmed as fake / tampered

Run:   python ml/build_real_dataset.py
Then:  python ml/train_model.py --data dataset/real_features.csv
"""
import os
import sys
import tempfile

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import BASE_DIR                      # noqa: E402
from ml.feature_extractor import FEATURE_NAMES   # noqa: E402
from services.analyzer import analyze_file       # noqa: E402

ROOT = os.path.join(BASE_DIR, "dataset", "real")
OUTPUT = os.path.join(BASE_DIR, "dataset", "real_features.csv")
LABELS = {"suspicious": 0, "genuine": 1}


def main():
    rows = []
    for folder, label in LABELS.items():
        path = os.path.join(ROOT, folder)
        if not os.path.isdir(path):
            print(f"[skip] folder not found: {path}")
            continue
        for name in sorted(os.listdir(path)):
            ext = name.rsplit(".", 1)[-1].lower()
            if ext not in ("jpg", "jpeg", "png", "pdf"):
                continue
            try:
                with tempfile.TemporaryDirectory() as tmp:
                    result = analyze_file(os.path.join(path, name), name, ext, work_dir=tmp)
                row = dict(result["features"])
                row["label"] = label
                rows.append(row)
                print(f"[ok]   {folder}/{name}")
            except Exception as exc:
                print(f"[fail] {folder}/{name}: {exc}")
    if not rows:
        print("No files processed. Put files in dataset/real/genuine and dataset/real/suspicious.")
        return
    pd.DataFrame(rows)[FEATURE_NAMES + ["label"]].to_csv(OUTPUT, index=False)
    print(f"\nSaved {len(rows)} rows to {OUTPUT}")


if __name__ == "__main__":
    main()
