"""SQLite helper functions: stores the history of analyses."""
import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime

from config import Config


class DatabaseError(Exception):
    """Raised when something goes wrong with the SQLite database."""


@contextmanager
def _connect():
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except sqlite3.Error as exc:
        conn.rollback()
        raise DatabaseError(str(exc)) from exc
    finally:
        conn.close()


def init_db():
    """Create the table if it does not exist yet."""
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS analyses (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                filename     TEXT NOT NULL,
                upload_time  TEXT NOT NULL,
                prediction   TEXT NOT NULL,
                confidence   REAL NOT NULL,
                ocr_text     TEXT,
                qr_detected  INTEGER DEFAULT 0,
                file_type    TEXT,
                result_json  TEXT
            )
            """
        )


def save_analysis(result):
    """Save one analysis result (a dict) and return the new row id."""
    with _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO analyses
                (filename, upload_time, prediction, confidence,
                 ocr_text, qr_detected, file_type, result_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result["filename"],
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                result["prediction"],
                float(result["confidence"]),
                result.get("ocr_text", ""),
                1 if result["qr"]["detected"] else 0,
                result["file_type"],
                json.dumps(result, default=str),
            ),
        )
        return cur.lastrowid


def get_all_analyses():
    with _connect() as conn:
        rows = conn.execute(
            "SELECT id, filename, upload_time, prediction, confidence, "
            "qr_detected, file_type FROM analyses ORDER BY id DESC"
        ).fetchall()
    return [dict(r) for r in rows]


def get_analysis(analysis_id):
    """Return (row_dict, result_dict) or (None, None)."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM analyses WHERE id = ?", (analysis_id,)
        ).fetchone()
    if row is None:
        return None, None
    row = dict(row)
    try:
        result = json.loads(row["result_json"])
    except (TypeError, ValueError):
        return row, None
    return row, result


def _remove_files(result_json):
    try:
        files = json.loads(result_json).get("files", [])
    except (TypeError, ValueError):
        files = []
    for name in files:
        path = os.path.join(Config.UPLOAD_FOLDER, os.path.basename(name))
        if os.path.isfile(path):
            try:
                os.remove(path)
            except OSError:
                pass


def delete_analysis(analysis_id):
    """Delete one record and its stored files. Returns True if deleted."""
    with _connect() as conn:
        row = conn.execute(
            "SELECT result_json FROM analyses WHERE id = ?", (analysis_id,)
        ).fetchone()
        if row is None:
            return False
        conn.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))
    _remove_files(row["result_json"])
    return True


def clear_all():
    with _connect() as conn:
        rows = conn.execute("SELECT result_json FROM analyses").fetchall()
        conn.execute("DELETE FROM analyses")
    for row in rows:
        _remove_files(row["result_json"])


def get_stats():
    with _connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM analyses").fetchone()[0]
        sus = conn.execute(
            "SELECT COUNT(*) FROM analyses WHERE prediction = ?",
            (Config.LABEL_SUSPICIOUS,),
        ).fetchone()[0]
    return {"total": total, "suspicious": sus, "genuine": total - sus}
