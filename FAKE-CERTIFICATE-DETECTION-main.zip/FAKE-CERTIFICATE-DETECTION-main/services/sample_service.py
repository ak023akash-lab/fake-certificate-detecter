"""Generates sample certificates for testing fake certificate detection."""
import os
import sys
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BASE_DIR, Config

SAMPLES_DIR = os.path.join(BASE_DIR, "static", "samples")
os.makedirs(SAMPLES_DIR, exist_ok=True)


def create_sample_certificates():
    genuine_path = os.path.join(SAMPLES_DIR, "sample_genuine_certificate.png")
    suspicious_path = os.path.join(SAMPLES_DIR, "sample_suspicious_certificate.png")

    # 1. Genuine Certificate (Crisp, high contrast, clean borders, proper metadata, QR code)
    w, h = 1800, 1280
    img = Image.new("RGB", (w, h), color=(253, 253, 252))
    draw = ImageDraw.Draw(img)

    # Decorative Border
    draw.rectangle([(30, 30), (w - 30, h - 30)], outline=(30, 60, 140), width=6)
    draw.rectangle([(45, 45), (w - 45, h - 45)], outline=(200, 170, 70), width=2)
    draw.rectangle([(55, 55), (w - 55, h - 55)], outline=(30, 60, 140), width=1)

    # Corner ornaments
    for cx, cy in [(45, 45), (w - 45, 45), (45, h - 45), (w - 45, h - 45)]:
        draw.rectangle([(cx - 15, cy - 15), (cx + 15, cy + 15)], fill=(200, 170, 70))

    # Header / Institution
    draw.text((w // 2, 140), "GLOBAL ACADEMIC & RESEARCH FOUNDATION", fill=(20, 40, 90), anchor="mm")
    draw.text((w // 2, 180), "DEPARTMENT OF ADVANCED COMPUTING & ARTIFICIAL INTELLIGENCE", fill=(80, 90, 110), anchor="mm")

    # Title
    draw.text((w // 2, 290), "CERTIFICATE OF EXCELLENCE", fill=(180, 130, 30), anchor="mm")
    draw.text((w // 2, 340), "THIS IS PROUDLY PRESENTED TO", fill=(100, 110, 130), anchor="mm")

    # Candidate Name
    draw.text((w // 2, 440), "DR. ELEANOR VANCE", fill=(15, 30, 70), anchor="mm")
    draw.line([(w // 2 - 320, 480), (w // 2 + 320, 480)], fill=(200, 170, 70), width=2)

    # Description
    desc1 = "for successfully completing with outstanding distinction the specialized program on"
    desc2 = "Advanced Neural Networks, Computer Vision & Cryptographic Security Verification"
    desc3 = "demonstrating exceptional mastery in deep learning architectures and data integrity analysis."
    draw.text((w // 2, 540), desc1, fill=(60, 70, 85), anchor="mm")
    draw.text((w // 2, 600), desc2, fill=(20, 35, 80), anchor="mm")
    draw.text((w // 2, 650), desc3, fill=(60, 70, 85), anchor="mm")

    # Details Grid
    draw.text((250, 790), "Certificate ID : CERT-2025-98412", fill=(40, 50, 70))
    draw.text((250, 830), "Date of Issue  : October 14, 2025", fill=(40, 50, 70))
    draw.text((250, 870), "Grade / Result : Grade A+ (Honors)", fill=(40, 50, 70))
    draw.text((250, 910), "Verification   : https://verify.globalacademic.org/check/CERT-2025-98412", fill=(40, 50, 70))

    # Gold Seal / Logo representation
    seal_center = (w - 320, 860)
    draw.ellipse([(seal_center[0] - 65, seal_center[1] - 65), (seal_center[0] + 65, seal_center[1] + 65)],
                 fill=(220, 180, 60), outline=(170, 130, 30), width=4)
    draw.ellipse([(seal_center[0] - 50, seal_center[1] - 50), (seal_center[0] + 50, seal_center[1] + 50)],
                 outline=(255, 255, 255), width=2)
    draw.text(seal_center, "OFFICIAL\nSEAL", fill=(120, 80, 10), anchor="mm", align="center")

    # Signature line
    draw.line([(w // 2 - 180, 1080), (w // 2 + 180, 1080)], fill=(80, 90, 110), width=1)
    # Simulated signature curve
    sig_points = [(w // 2 - 120, 1055), (w // 2 - 80, 1030), (w // 2 - 40, 1060),
                  (w // 2, 1025), (w // 2 + 50, 1050), (w // 2 + 90, 1035), (w // 2 + 130, 1060)]
    for i in range(len(sig_points) - 1):
        draw.line([sig_points[i], sig_points[i+1]], fill=(10, 25, 80), width=3)
    draw.text((w // 2, 1110), "Director & Controller of Examinations", fill=(80, 90, 110), anchor="mm")

    # QR Code placeholder (clean sharp square)
    qr_x, qr_y, qr_s = 140, 780, 90
    draw.rectangle([(qr_x, qr_y), (qr_x + qr_s, qr_y + qr_s)], fill=(255, 255, 255), outline=(0, 0, 0), width=2)
    for qrx in range(qr_x + 8, qr_x + qr_s - 8, 12):
        for qry in range(qr_y + 8, qr_y + qr_s - 8, 12):
            if (qrx + qry) % 3 == 0:
                draw.rectangle([(qrx, qry), (qrx + 8, qry + 8)], fill=(0, 0, 0))
    # QR corners
    draw.rectangle([(qr_x + 6, qr_y + 6), (qr_x + 26, qr_y + 26)], fill=(0, 0, 0))
    draw.rectangle([(qr_x + qr_s - 26, qr_y + 6), (qr_x + qr_s - 6, qr_y + 26)], fill=(0, 0, 0))
    draw.rectangle([(qr_x + 6, qr_y + qr_s - 26), (qr_x + 26, qr_y + qr_s - 6)], fill=(0, 0, 0))

    img.save(genuine_path, format="PNG")

    # 2. Suspicious / Tampered Certificate (Heavy noise, blurred, inconsistent text, cropped border, low contrast)
    arr = np.array(img)
    # Add heavy Gaussian noise
    noise = np.random.normal(0, 28, arr.shape).astype(np.float32)
    noisy = np.clip(arr.astype(np.float32) + noise, 0, 255).astype(np.uint8)

    # Blur heavily
    blurred = cv2.GaussianBlur(noisy, (7, 7), 2.5)

    # Compress contrast
    low_contrast = cv2.convertScaleAbs(blurred, alpha=0.65, beta=60)

    # Convert back to PIL to insert an obvious forged text patch with different font/background
    suspicious_pil = Image.fromarray(low_contrast)
    s_draw = ImageDraw.Draw(suspicious_pil)

    # Erase original name with a messy patch and write mismatched name
    s_draw.rectangle([(w // 2 - 350, 410), (w // 2 + 350, 470)], fill=(240, 235, 220))
    s_draw.text((w // 2, 440), "JOHN DOE (MODIFIED)", fill=(10, 10, 10), anchor="mm")

    # Erase certificate ID and leave it blank/corrupt
    s_draw.rectangle([(240, 785), (600, 825)], fill=(230, 225, 215))

    suspicious_pil.save(suspicious_path, format="PNG")
    print(f"Sample certificates created in {SAMPLES_DIR}")


if __name__ == "__main__":
    create_sample_certificates()
