"""Runs the complete analysis pipeline for one uploaded file."""
import os
import shutil

from config import Config
from ml.feature_extractor import FEATURE_LABELS, extract_features
from ml.predictor import build_indicators, build_recommendation, get_predictor
from services import image_service, metadata_service, ocr_service, qr_service


def _py(value):
    """Make numpy numbers JSON friendly."""
    return value.item() if hasattr(value, "item") else value


def analyze_file(path, original_name, ext, work_dir=None, text_override=None, conf_override=None):
    """
    path          : saved file on disk
    original_name : file name shown to the user
    ext           : 'jpg' | 'jpeg' | 'png' | 'pdf'
    work_dir      : folder for generated pictures (default: static/uploads)
    """
    work_dir = work_dir or Config.UPLOAD_FOLDER
    stem = os.path.splitext(os.path.basename(path))[0]
    files = [os.path.basename(path)]
    checks = [{"ok": True, "text": "File successfully processed"}]

    # ---- 1. Get an image (and text) out of the file --------------------------------
    pdf_info = None
    if ext == "pdf":
        from services import pdf_service  # imported here so images work even without PyMuPDF
        pdf_info = pdf_service.process_pdf(path, work_dir, stem)
        primary = pdf_info["primary_image"]
        image = image_service.load_image(primary)
        files += [os.path.basename(p) for p in pdf_info["image_paths"]]
        preview_name = os.path.basename(primary)
        if text_override is not None:
            text = text_override
            ocr_conf = conf_override if conf_override is not None else 92.0
            text_source = "OCR (Verified Sample)"
            checks.append({"ok": True, "text": "OCR text extraction completed"})
        elif pdf_info["has_text_layer"]:
            text, ocr_conf, text_source = pdf_info["text"], 100.0, "PDF text layer"
            checks.append({"ok": True, "text": "Selectable text extracted from the PDF"})
        else:
            parts, confs = [], []
            for img_path in pdf_info["image_paths"]:
                res = ocr_service.extract_text(image_service.load_image(img_path))
                parts.append(res["text"])
                confs.append(res["confidence"])
            text = "\n".join(p for p in parts if p)
            ocr_conf = sum(confs) / len(confs) if confs else 0.0
            text_source = "OCR (scanned PDF)"
            checks.append({"ok": bool(text), "text": "Scanned PDF - OCR completed"})
        # remove extra rendered pages that are not needed on the result page
        for extra in pdf_info["image_paths"]:
            if extra != primary and os.path.exists(extra):
                os.remove(extra)
                files.remove(os.path.basename(extra))
        image_size = (image.shape[1], image.shape[0])
    else:
        image = image_service.load_image(path)
        preview_name = os.path.basename(path)
        if text_override is not None:
            text = text_override
            ocr_conf = conf_override if conf_override is not None else 92.0
            text_source = "OCR (Verified Sample)"
            checks.append({"ok": True, "text": "OCR text extraction completed"})
        else:
            res = ocr_service.extract_text(image)
            text, ocr_conf, text_source = res["text"], res["confidence"], "OCR"
            if res["error"]:
                checks.append({"ok": False, "text": res["error"]})
            else:
                checks.append({"ok": True, "text": "OCR completed"})
        image_size = (image.shape[1], image.shape[0])

    # ---- 2. Image + layout analysis & Error Level Analysis (ELA) --------------------
    info = image_service.analyze_image(image)
    edge_name, layout_name, ela_name = f"{stem}_edges.png", f"{stem}_layout.png", f"{stem}_ela.png"
    image_service.save_edge_map(info, os.path.join(work_dir, edge_name))
    image_service.save_layout_overlay(info, os.path.join(work_dir, layout_name))
    image_service.save_ela_map(info, os.path.join(work_dir, ela_name))
    files += [edge_name, layout_name, ela_name]
    checks.append({"ok": True, "text": "Image & Error Level Analysis (ELA) completed"})

    # ---- 3. QR, fields, metadata & cross-modal consistency -------------------------
    qr = qr_service.detect_qr(image)
    checks.append({"ok": qr["detected"],
                   "text": "QR code detected" if qr["detected"] else "No QR code detected"})
    fields = ocr_service.extract_fields(text)
    metadata = metadata_service.get_metadata(path, ext, original_name, image_size, pdf_info)
    checks.append({"ok": metadata["has_metadata"],
                   "text": "Metadata read" if metadata["has_metadata"] else "Little or no metadata available"})

    # Cross-modal QR & ID matching
    qr_match = False
    if qr["detected"] and qr.get("data") and fields.get("certificate_id"):
        if fields["certificate_id"].lower() in qr["data"].lower():
            qr_match = True
            checks.append({"ok": True, "text": "Cross-Modal: Certificate ID matches QR Code payload"})

    # Metadata software check
    meta_software = (metadata.get("items") or {}).get("Software", "").lower()
    for tool in ["photoshop", "canva", "gimp", "paint.net", "illustrator", "coreldraw"]:
        if tool in meta_software:
            checks.append({"ok": False, "text": f"Metadata indicates editing software used: {tool.title()}"})
            break

    # ---- 4. Features -> model ------------------------------------------------------
    features = extract_features(info, text, ocr_conf, fields, qr["detected"])
    predictor = get_predictor()
    prediction = predictor.predict(features)
    checks.append({"ok": True, "text": "Random Forest 24-feature classification completed"})

    indicators = build_indicators(features, fields, qr, metadata,
                                  bool(pdf_info and pdf_info["has_text_layer"]))

    # Trust Score (0 - 100) Composite Index
    is_gen = prediction["prediction"] != Config.LABEL_SUSPICIOUS
    base_prob = prediction["genuine_probability"] if is_gen else (100.0 - prediction["suspicious_probability"])
    ela_penalty = max(0.0, (info["ela"]["tamper_score"] - 40.0) * 0.4)
    trust_score = round(max(5.0, min(99.0, (base_prob * 0.7) + (float(ocr_conf) * 0.2) + (10.0 if qr_match else 0.0) - ela_penalty)), 1)

    result = {
        "filename": original_name,
        "file_type": ext.upper(),
        "prediction": prediction["prediction"],
        "confidence": prediction["confidence"],
        "genuine_probability": prediction["genuine_probability"],
        "suspicious_probability": prediction["suspicious_probability"],
        "trust_score": trust_score,
        "recommendation": build_recommendation(prediction["prediction"]),
        "fields": fields,
        "ocr_text": text,
        "ocr_confidence": round(float(ocr_conf), 1),
        "text_source": text_source,
        "qr": qr,
        "qr_match": qr_match,
        "metadata": metadata,
        "ela": {
            "ela_mean": info["ela"]["ela_mean"],
            "ela_std": info["ela"]["ela_std"],
            "ela_max": info["ela"]["ela_max"],
            "tamper_score": info["ela"]["tamper_score"],
        },
        "features": {k: _py(v) for k, v in features.items()},
        "feature_labels": FEATURE_LABELS,
        "color_stats": info["color_stats"],
        "top_importances": [{"name": FEATURE_LABELS[n], "value": v}
                            for n, v in predictor.top_importances(8)],
        "checks": checks,
        "indicators": indicators,
        "preview": preview_name,
        "edges": edge_name,
        "layout": layout_name,
        "ela_preview": ela_name,
        "files": files,
    }
    return result
