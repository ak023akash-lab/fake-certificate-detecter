"""QR service: finds and decodes QR codes with OpenCV (no verification is claimed)."""
from urllib.parse import urlparse

import cv2

VERIFY_MESSAGE = "QR data extracted; external verification required."


def _candidate_images(image_bgr):
    """Whole image, enlarged copy, and the four quarters (QR codes are often in a corner)."""
    h, w = image_bgr.shape[:2]
    yield image_bgr
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    yield gray
    for ys, ye, xs, xe in [(0, 0.5, 0, 0.5), (0, 0.5, 0.5, 1), (0.5, 1, 0, 0.5), (0.5, 1, 0.5, 1)]:
        crop = gray[int(h * ys):int(h * ye), int(w * xs):int(w * xe)]
        yield cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)


def detect_qr(image_bgr):
    """Return a dictionary describing the QR code (if any)."""
    result = {"detected": False, "decoded": False, "data": "", "is_url": False,
              "host": "", "uses_https": False, "message": "No QR code detected."}
    detector = cv2.QRCodeDetector()
    found_pattern = False

    for candidate in _candidate_images(image_bgr):
        try:
            data, points, _ = detector.detectAndDecode(candidate)
        except cv2.error:
            continue
        if points is not None and len(points) > 0:
            found_pattern = True
        if data:
            data = data.strip()[:500]
            result.update(detected=True, decoded=True, data=data, message=VERIFY_MESSAGE)
            parsed = urlparse(data)
            if parsed.scheme in ("http", "https") and parsed.netloc:
                result.update(is_url=True, host=parsed.netloc, uses_https=parsed.scheme == "https")
            return result

    if found_pattern:
        result.update(detected=True,
                      message="A QR-like pattern was found but it could not be decoded.")
    return result
