"""OCR service: reads text from a certificate image using Tesseract."""
import os
import re
import shutil

import cv2
import pytesseract
from pytesseract import Output

from config import Config


class OCRUnavailableError(Exception):
    """Raised when the Tesseract program is not installed / not found."""


INSTALL_HELP = (
    "Tesseract OCR is not installed or could not be found. "
    "Windows: download the installer from https://github.com/UB-Mannheim/tesseract/wiki, "
    "install it to the default folder (C:\\Program Files\\Tesseract-OCR) and restart this app. "
    "If you installed it elsewhere, set TESSERACT_CMD in config.py to the full path of tesseract.exe."
)

_WINDOWS_PATHS = [
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"),
]


def configure_tesseract():
    """Point pytesseract to the Tesseract executable."""
    if Config.TESSERACT_CMD:
        pytesseract.pytesseract.tesseract_cmd = Config.TESSERACT_CMD
        return
    if shutil.which("tesseract"):
        return
    for path in _WINDOWS_PATHS:
        if os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            return


def is_tesseract_available():
    configure_tesseract()
    try:
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
# OCR
# --------------------------------------------------------------------------
def _prepare_for_ocr(image_bgr):
    """Grayscale -> upscale small images -> contrast enhancement -> light denoise."""
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    longest = max(gray.shape)
    if longest < 1600:
        scale = 1600.0 / longest
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    return cv2.medianBlur(gray, 3)


def _run_tesseract(image):
    data = pytesseract.image_to_data(
        image, output_type=Output.DICT, config="--oem 3 --psm 3"
    )
    lines, confs = {}, []
    for i, word in enumerate(data["text"]):
        word = word.strip()
        if not word:
            continue
        try:
            conf = float(data["conf"][i])
        except (TypeError, ValueError):
            conf = -1
        if conf >= 0:
            confs.append(conf)
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        lines.setdefault(key, []).append(word)
    text = "\n".join(" ".join(words) for _, words in sorted(lines.items()))
    mean_conf = sum(confs) / len(confs) if confs else 0.0
    return text, mean_conf


def extract_text(image_bgr):
    """Return {'text', 'confidence', 'error'}. Never crashes the app on OCR failure."""
    configure_tesseract()
    try:
        prepared = _prepare_for_ocr(image_bgr)
        text, conf = _run_tesseract(prepared)
        if conf < 45:  # second attempt with Otsu thresholding
            _, binary = cv2.threshold(prepared, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            text2, conf2 = _run_tesseract(binary)
            if conf2 > conf:
                text, conf = text2, conf2
        return {"text": clean_text(text), "confidence": round(conf, 2), "error": None}
    except pytesseract.TesseractNotFoundError:
        return {"text": "", "confidence": 0.0, "error": "Tesseract OCR is not installed. Text OCR was skipped, but image and structural analysis ran."}
    except Exception as exc:  # any other OCR problem
        return {"text": "", "confidence": 0.0, "error": f"OCR failed: {exc.__class__.__name__}"}


def clean_text(text):
    """Remove control characters, extra spaces and blank lines."""
    text = re.sub(r"[^\x09\x0A\x20-\x7E\u00A0-\uFFFF]", " ", text or "")
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in text.splitlines()]
    return "\n".join(ln for ln in lines if ln)


# --------------------------------------------------------------------------
# Field extraction (rule based - certificates differ, so every field is optional)
# --------------------------------------------------------------------------
_NAME_WORD = r"[A-Z][A-Za-z.'\-]+"
_NAME = rf"({_NAME_WORD}(?:\s+{_NAME_WORD}){{1,3}})"

_NAME_PATTERNS = [
    rf"(?i:certify that|certifies that|awarded to|presented to|proudly presented to|"
    rf"conferred upon|granted to|issued to|name of (?:the )?(?:student|candidate|participant)|"
    rf"student name|candidate name|participant|name)\s*[:\-]?\s*{_NAME}",
    rf"\b(?:Mr|Ms|Mrs|Miss|Dr|Shri|Smt)\.?\s+{_NAME}",
]

_ID_KEYWORD = (
    r"(?i:certificate|cert\.?|credential|serial|registration|reg\.?|enrol+ment|"
    r"roll|reference|ref\.?|verification|license|licence|id)"
)
_ID_PATTERN = (
    rf"{_ID_KEYWORD}\s*(?i:no\.?|number|id|code|#)?\s*[:\-#]?\s*"
    rf"([A-Z0-9][A-Z0-9\-/]{{4,24}})"
)

_DATE_PATTERNS = [
    r"\b\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}\b",
    r"\b\d{4}[/\-.]\d{1,2}[/\-.]\d{1,2}\b",
    r"\b\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?,?\s+\d{4}\b",
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b",
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}\b",
]

_INSTITUTION_WORDS = (
    "university", "institute", "institution", "college", "academy", "school",
    "foundation", "council", "board", "society", "association", "organisation",
    "organization", "department", "ministry", "polytechnic", "ltd", "limited",
    "inc", "pvt", "coursera", "udemy", "edx", "nptel", "infosys", "google",
    "microsoft", "amazon", "ibm",
)

_COURSE_PATTERN = (
    r"(?i:successfully completed|has completed|completion of|completed the|course on|"
    r"course in|course of|programme in|program in|programme on|program on|degree of|"
    r"diploma in|certificate in|certificate of completion in|training on|training in|"
    r"workshop on|bootcamp in|specialization in|specialisation in)\s*[:\-]?\s*([^\n]{3,80})"
)

_GRADE_PATTERN = (
    r"(?i:\b(?:grade|cgpa|gpa|percentage|marks(?: obtained)?|score|division|result)\b)"
    r"\s*[:\-=]?\s*([A-Za-z0-9+.%/]{1,10})"
)


def extract_fields(text):
    """Find name, institution, certificate ID, course, date, grade and other info."""
    fields = {"name": None, "institution": None, "certificate_id": None,
              "course": None, "date": None, "grade": None, "other": []}
    if not text:
        return fields

    # Name
    for pattern in _NAME_PATTERNS:
        m = re.search(pattern, text)
        if m:
            fields["name"] = m.group(1).strip()
            break

    # Institution (first short line that mentions an institution word)
    for line in text.splitlines():
        low = line.lower()
        if 4 < len(line) <= 90 and any(re.search(rf"\b{w}\b", low) for w in _INSTITUTION_WORDS):
            tokens = line.split()
            while tokens and len(re.sub(r"\W", "", tokens[0])) < 2:   # drop OCR junk such as "(>"
                tokens.pop(0)
            if tokens:
                fields["institution"] = " ".join(tokens)
                break

    # Certificate ID (must contain at least one digit)
    for m in re.finditer(_ID_PATTERN, text):
        candidate = m.group(1).strip("-/")
        if any(ch.isdigit() for ch in candidate):
            fields["certificate_id"] = candidate
            break
    if not fields["certificate_id"]:
        m = re.search(r"\b[A-Z]{2,6}[-/]?\d{4,}[A-Z0-9\-/]*\b", text)
        if m:
            fields["certificate_id"] = m.group(0)

    # Course
    m = re.search(_COURSE_PATTERN, text)
    if m:
        course = m.group(1).strip(" .,:;-")
        course = re.sub(r"^(?i:the\s+)?(?i:course|programme|program|training|workshop)\s+(?:on|in|of)\s+", "", course)
        course = re.sub(r"^(?i:the|a|an)\s+", "", course)
        fields["course"] = course.strip(" .,:;-")

    # Date
    for pattern in _DATE_PATTERNS:
        m = re.search(pattern, text, flags=re.IGNORECASE)
        if m:
            fields["date"] = m.group(0).strip()
            break

    # Grade / marks
    m = re.search(_GRADE_PATTERN, text)
    if m and any(ch.isalnum() for ch in m.group(1)):
        fields["grade"] = m.group(1).strip(".,:;")

    # Other visible information
    email = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    if email:
        fields["other"].append(f"Email: {email.group(0)}")
    url = re.search(r"(?:https?://|www\.)[^\s]+", text, flags=re.IGNORECASE)
    if url:
        fields["other"].append(f"Website: {url.group(0)}")
    for title in ("Director", "Registrar", "Principal", "Dean", "Controller of Examinations",
                  "Chairman", "Signature", "Signatory", "CEO", "Instructor"):
        if re.search(rf"\b{title}\b", text, flags=re.IGNORECASE):
            fields["other"].append(f"Signatory mention: {title}")
            break
    return fields
