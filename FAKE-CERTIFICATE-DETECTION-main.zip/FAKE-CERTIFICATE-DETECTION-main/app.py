"""
Fake Certificate Detection Using Machine Learning - Single Page Application Flask Server.

Run:  python app.py      then open  http://127.0.0.1:5000
"""
import json
import os
import shutil
import uuid
from datetime import datetime

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from PIL import Image
from werkzeug.utils import secure_filename

from config import BASE_DIR, Config
from database import database as db
from ml.predictor import ModelNotFoundError
from services import ocr_service
from services.analyzer import analyze_file
from services.image_service import ImageProcessingError

app = Flask(__name__)
app.config.from_object(Config)

SIGNATURES = {
    "jpg": [b"\xff\xd8\xff"],
    "jpeg": [b"\xff\xd8\xff"],
    "png": [b"\x89PNG\r\n\x1a\n"],
    "pdf": [b"%PDF-"],
}

SAMPLES_DIR = os.path.join(BASE_DIR, "static", "samples")


# --------------------------------------------------------------------------
# Start-up: create database, train a demo model if none exists, create samples
# --------------------------------------------------------------------------
def bootstrap():
    try:
        db.init_db()
    except db.DatabaseError as exc:
        print(f"[WARNING] Database could not be initialised: {exc}")
    if not os.path.exists(Config.MODEL_PATH):
        print("[INFO] No trained model found - creating a demo model automatically...")
        try:
            from ml.dataset_generator import generate_dataset
            from ml.train_model import train_model
            generate_dataset()
            train_model()
        except Exception as exc:
            print(f"[WARNING] Automatic training failed: {exc}")

    try:
        from services.sample_service import create_sample_certificates
        if not os.path.exists(os.path.join(SAMPLES_DIR, "sample_genuine_certificate.png")):
            create_sample_certificates()
    except Exception as exc:
        print(f"[WARNING] Sample certificate generation skipped: {exc}")


def load_model_info():
    try:
        with open(Config.METRICS_PATH, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------
# Upload validation
# --------------------------------------------------------------------------
def validate_and_save(file):
    """Returns (saved_path, extension, error_message)."""
    if file is None or not file.filename:
        return None, None, "Please choose a certificate file first."

    original = secure_filename(file.filename)
    ext = original.rsplit(".", 1)[-1].lower() if "." in original else ""
    if ext not in Config.ALLOWED_EXTENSIONS:
        return None, None, "Unsupported file type. Please upload a JPG, JPEG, PNG or PDF file."

    header = file.stream.read(16)
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(0)
    if size == 0:
        return None, None, "The uploaded file is empty."
    if size > Config.MAX_FILE_SIZE_MB * 1024 * 1024:
        return None, None, f"The file is too large. Maximum allowed size is {Config.MAX_FILE_SIZE_MB} MB."
    if not any(header.startswith(sig) for sig in SIGNATURES[ext]):
        return None, None, "The file content does not match its extension. Upload a real image or PDF."

    stored = f"{uuid.uuid4().hex[:10]}_{original}"
    path = os.path.join(Config.UPLOAD_FOLDER, stored)
    file.save(path)

    if ext in ("jpg", "jpeg", "png"):
        try:
            with Image.open(path) as img:
                img.verify()
        except Exception:
            os.remove(path)
            return None, None, "The image is corrupt or not a valid image file."
    return path, ext, None


def _cleanup(path):
    """Remove an upload (and files generated from it) after a failed analysis."""
    if not path:
        return
    stem = os.path.splitext(os.path.basename(path))[0]
    for name in os.listdir(Config.UPLOAD_FOLDER):
        if name.startswith(stem):
            try:
                os.remove(os.path.join(Config.UPLOAD_FOLDER, name))
            except OSError:
                pass


# --------------------------------------------------------------------------
# Template Context Processor (Always injects stats)
# --------------------------------------------------------------------------
@app.context_processor
def inject_global_stats():
    try:
        stats = db.get_stats()
    except Exception:
        stats = {"total": 0, "suspicious": 0, "genuine": 0}
    return {"stats": stats}


# --------------------------------------------------------------------------
# Single Page View & Traditional Routes
# --------------------------------------------------------------------------
@app.route("/")
def index():
    try:
        stats = db.get_stats()
    except db.DatabaseError:
        stats = {"total": 0, "suspicious": 0, "genuine": 0}

    try:
        rows = db.get_all_analyses()
    except db.DatabaseError:
        rows = []

    samples = []
    if os.path.isdir(SAMPLES_DIR):
        for fname in os.listdir(SAMPLES_DIR):
            if fname.endswith((".png", ".jpg", ".jpeg", ".pdf")):
                samples.append(fname)

    return render_template(
        "index.html",
        stats=stats,
        rows=rows,
        model_info=load_model_info(),
        tesseract_ok=ocr_service.is_tesseract_available(),
        max_mb=Config.MAX_FILE_SIZE_MB,
        samples=samples,
    )


# --------------------------------------------------------------------------
# Single Page REST API Endpoints
# --------------------------------------------------------------------------
@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    file = request.files.get("certificate")
    path, ext, error = validate_and_save(file)
    if error:
        return jsonify({"ok": False, "error": error}), 400

    original_name = secure_filename(file.filename)
    try:
        result = analyze_file(path, original_name, ext)
    except ocr_service.OCRUnavailableError as exc:
        _cleanup(path)
        return jsonify({"ok": False, "error": str(exc), "code": "OCR_UNAVAILABLE"}), 422
    except ModelNotFoundError as exc:
        _cleanup(path)
        return jsonify({"ok": False, "error": str(exc), "code": "MODEL_NOT_FOUND"}), 500
    except Exception as exc:
        _cleanup(path)
        if exc.__class__.__name__ == "PDFProcessingError" or isinstance(exc, ImageProcessingError):
            return jsonify({"ok": False, "error": str(exc)}), 422
        app.logger.exception("Analysis failed")
        return jsonify({"ok": False, "error": f"Analysis failed: {str(exc)}"}), 500

    try:
        analysis_id = db.save_analysis(result)
        stats = db.get_stats()
        saved_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return jsonify({
            "ok": True,
            "analysis_id": analysis_id,
            "result": result,
            "stats": stats,
            "saved_at": saved_at
        })
    except db.DatabaseError as exc:
        return jsonify({
            "ok": True,
            "analysis_id": None,
            "result": result,
            "stats": {"total": 0, "suspicious": 0, "genuine": 0},
            "warning": "Analysis succeeded but history record could not be saved."
        })


@app.route("/api/analyze_sample", methods=["POST"])
def api_analyze_sample():
    data = request.get_json(silent=True) or {}
    sample_key = data.get("sample", "genuine")

    sample_filename = "sample_genuine_certificate.png" if sample_key == "genuine" else "sample_suspicious_certificate.png"
    sample_src = os.path.join(SAMPLES_DIR, sample_filename)

    if not os.path.exists(sample_src):
        try:
            from services.sample_service import create_sample_certificates
            create_sample_certificates()
        except Exception as exc:
            return jsonify({"ok": False, "error": f"Sample generation failed: {exc}"}), 500

    if not os.path.exists(sample_src):
        return jsonify({"ok": False, "error": "Sample file not found."}), 404

    target_name = f"{uuid.uuid4().hex[:10]}_{sample_filename}"
    target_path = os.path.join(Config.UPLOAD_FOLDER, target_name)
    shutil.copy2(sample_src, target_path)

    ext = "png"
    original_name = "Official_Genuine_Certificate_Sample.png" if sample_key == "genuine" else "Modified_Suspicious_Certificate_Sample.png"

    text_override = None
    conf_override = None
    if not ocr_service.is_tesseract_available():
        if sample_key == "genuine":
            text_override = (
                "GLOBAL ACADEMIC & RESEARCH FOUNDATION\n"
                "DEPARTMENT OF ADVANCED COMPUTING & ARTIFICIAL INTELLIGENCE\n"
                "CERTIFICATE OF EXCELLENCE\n"
                "THIS IS PROUDLY PRESENTED TO\n"
                "DR. ELEANOR VANCE\n"
                "for successfully completing with outstanding distinction the specialized program on\n"
                "Advanced Neural Networks, Computer Vision & Cryptographic Security Verification\n"
                "demonstrating exceptional mastery in deep learning architectures and data integrity analysis.\n"
                "Certificate ID : CERT-2025-98412\n"
                "Date of Issue  : October 14, 2025\n"
                "Grade / Result : Grade A+ (Honors)\n"
                "Verification   : https://verify.globalacademic.org/check/CERT-2025-98412\n"
                "Director & Controller of Examinations"
            )
            conf_override = 95.5
        else:
            text_override = (
                "GLOBAL ACADEMIC & RESEARCH FOUNDATION\n"
                "CERTIFICATE OF EXCELLENCE\n"
                "JOHN DOE (MODIFIED)\n"
                "Advanced Neural Networks\n"
                "Director"
            )
            conf_override = 45.0

    try:
        result = analyze_file(target_path, original_name, ext, text_override=text_override, conf_override=conf_override)
        analysis_id = db.save_analysis(result)
        stats = db.get_stats()
        saved_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return jsonify({
            "ok": True,
            "analysis_id": analysis_id,
            "result": result,
            "stats": stats,
            "saved_at": saved_at
        })
    except Exception as exc:
        _cleanup(target_path)
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/history", methods=["GET"])
def api_history():
    try:
        rows = db.get_all_analyses()
        stats = db.get_stats()
        return jsonify({"ok": True, "rows": rows, "stats": stats})
    except db.DatabaseError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/analysis/<int:analysis_id>", methods=["GET"])
def api_get_analysis(analysis_id):
    try:
        row, data = db.get_analysis(analysis_id)
        if row is None or data is None:
            return jsonify({"ok": False, "error": "Analysis not found."}), 404
        return jsonify({"ok": True, "row": row, "result": data})
    except db.DatabaseError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/delete/<int:analysis_id>", methods=["POST", "DELETE"])
def api_delete_analysis(analysis_id):
    try:
        deleted = db.delete_analysis(analysis_id)
        stats = db.get_stats()
        return jsonify({"ok": deleted, "stats": stats})
    except db.DatabaseError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/clear", methods=["POST"])
def api_clear_history():
    try:
        db.clear_all()
        stats = db.get_stats()
        return jsonify({"ok": True, "stats": stats})
    except db.DatabaseError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/stats", methods=["GET"])
def api_stats():
    try:
        stats = db.get_stats()
        return jsonify({"ok": True, "stats": stats})
    except db.DatabaseError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


# --------------------------------------------------------------------------
# Backwards compatibility routes
# --------------------------------------------------------------------------
@app.route("/analyze", methods=["POST"])
def analyze():
    path, ext, error = validate_and_save(request.files.get("certificate"))
    if error:
        flash(error, "error")
        return redirect(url_for("index"))

    original_name = secure_filename(request.files["certificate"].filename)
    try:
        result = analyze_file(path, original_name, ext)
        analysis_id = db.save_analysis(result)
        return redirect(f"/?id={analysis_id}#results")
    except Exception as exc:
        _cleanup(path)
        flash(str(exc), "error")
        return redirect(url_for("index"))


@app.route("/result/<int:analysis_id>")
def result(analysis_id):
    return redirect(f"/?id={analysis_id}#results")


@app.route("/history")
def history():
    return redirect("/#history")


@app.route("/about")
def about():
    return redirect("/#about")


@app.route("/delete/<int:analysis_id>", methods=["POST"])
def delete(analysis_id):
    try:
        db.delete_analysis(analysis_id)
        flash("Analysis deleted.", "success")
    except db.DatabaseError:
        flash("Could not delete that record.", "error")
    return redirect("/#history")


@app.route("/clear", methods=["POST"])
def clear():
    try:
        db.clear_all()
        flash("All history and stored files were deleted.", "success")
    except db.DatabaseError:
        flash("Could not clear the history.", "error")
    return redirect("/#history")


# --------------------------------------------------------------------------
# Error handlers
# --------------------------------------------------------------------------
@app.errorhandler(413)
def too_large(_):
    if request.is_json or request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": f"File is too large. Max size is {Config.MAX_FILE_SIZE_MB} MB."}), 413
    flash(f"The file is too large. Maximum allowed size is {Config.MAX_FILE_SIZE_MB} MB.", "error")
    return redirect(url_for("index"))


@app.errorhandler(404)
def not_found(_):
    if request.is_json or request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "Not found"}), 404
    return render_template("error.html", code=404, message="That page does not exist."), 404


@app.errorhandler(500)
def server_error(_):
    if request.is_json or request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "Internal server error"}), 500
    return render_template("error.html", code=500, message="Something went wrong on the server."), 500


bootstrap()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=os.environ.get("FLASK_DEBUG") == "1")
