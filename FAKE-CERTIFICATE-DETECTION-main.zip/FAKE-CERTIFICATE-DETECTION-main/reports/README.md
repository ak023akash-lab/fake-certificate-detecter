# reports/

Created automatically when you run `python ml/train_model.py`:

- `model_metrics.json` - accuracy, precision, recall, F1-score, cross-validation score, confusion matrix and feature importances (also shown on the About page)
- `confusion_matrix.png` - picture of the confusion matrix, ready for your project report or slides
