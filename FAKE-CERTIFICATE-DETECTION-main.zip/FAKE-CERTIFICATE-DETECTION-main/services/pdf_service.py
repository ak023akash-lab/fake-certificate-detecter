"""PDF service: reads PDFs with PyMuPDF (text layer + page rendering)."""
import os
import re

import fitz  # PyMuPDF

from config import Config


class PDFProcessingError(Exception):
    """Raised when a PDF is corrupt, encrypted or empty."""


def process_pdf(path, out_dir, stem):
    """
    1. Open the PDF.
    2. Extract selectable text from the first pages.
    3. Render pages as PNG images (needed for image analysis and for OCR of scanned PDFs).
    """
    try:
        doc = fitz.open(path)
    except Exception as exc:
        raise PDFProcessingError("The PDF could not be opened. The file may be corrupt.") from exc

    try:
        if doc.needs_pass or doc.is_encrypted:
            raise PDFProcessingError("Password-protected PDFs are not supported.")
        if doc.page_count == 0:
            raise PDFProcessingError("The PDF has no pages.")

        pages_to_use = min(doc.page_count, Config.MAX_PDF_PAGES)
        page_texts = [doc[i].get_text("text") for i in range(pages_to_use)]
        text = "\n".join(page_texts).strip()
        has_text_layer = len(re.sub(r"\s", "", text)) >= 30

        # Choose the main page: the one with most text (first page for scanned PDFs)
        main_index = max(range(pages_to_use), key=lambda i: len(page_texts[i])) if has_text_layer else 0

        # Scanned PDF -> render every analysed page so OCR can read all of them.
        render_indexes = [main_index] if has_text_layer else list(range(pages_to_use))

        image_paths, primary = [], None
        for i in render_indexes:
            page = doc[i]
            longest_pt = max(page.rect.width, page.rect.height) or 1
            zoom = min(Config.PDF_RENDER_DPI / 72.0, 3000.0 / longest_pt)
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            img_path = os.path.join(out_dir, f"{stem}_page{i + 1}.png")
            pix.save(img_path)
            image_paths.append(img_path)
            if i == main_index:
                primary = img_path

        embedded_images = sum(len(doc[i].get_images()) for i in range(pages_to_use))
        return {
            "page_count": doc.page_count,
            "pages_analysed": pages_to_use,
            "has_text_layer": has_text_layer,
            "text": text,
            "image_paths": image_paths,
            "primary_image": primary,
            "metadata": dict(doc.metadata or {}),
            "pdf_format": (doc.metadata or {}).get("format", ""),
            "embedded_images": embedded_images,
        }
    except PDFProcessingError:
        raise
    except Exception as exc:
        raise PDFProcessingError("The PDF could not be processed. The file may be corrupt.") from exc
    finally:
        doc.close()
