"""Loads the trained model and turns feature values into a prediction."""
import os

import joblib
import pandas as pd

from config import Config


class ModelNotFoundError(Exception):
    """Raised when certificate_model.pkl does not exist yet."""


class CertificatePredictor:
    def __init__(self, model_path=None):
        self.model_path = model_path or Config.MODEL_PATH
        self._model = None
        self._feature_names = None

    def load(self):
        if self._model is None:
            if not os.path.exists(self.model_path):
                raise ModelNotFoundError(
                    "The trained model was not found. Run 'python ml/dataset_generator.py' "
                    "and then 'python ml/train_model.py', then restart the app.")
            bundle = joblib.load(self.model_path)
            self._model = bundle["model"]
            self._feature_names = bundle["feature_names"]
        return self._model

    def reload(self):
        self._model = None
        return self.load()

    def predict(self, features):
        """features: dict {feature_name: value}. Returns prediction, confidence and probabilities."""
        model = self.load()
        row = pd.DataFrame([[features[n] for n in self._feature_names]], columns=self._feature_names)
        proba = model.predict_proba(row)[0]
        p_genuine = float(proba[list(model.classes_).index(1)])
        if p_genuine >= 0.5:
            label, confidence = Config.LABEL_GENUINE, p_genuine
        else:
            label, confidence = Config.LABEL_SUSPICIOUS, 1.0 - p_genuine
        return {
            "prediction": label,
            "confidence": round(confidence * 100, 1),   # model confidence, NOT proof
            "genuine_probability": round(p_genuine * 100, 1),
            "suspicious_probability": round((1 - p_genuine) * 100, 1),
        }

    def top_importances(self, n=8):
        model = self.load()
        pairs = sorted(zip(self._feature_names, model.feature_importances_),
                       key=lambda t: t[1], reverse=True)[:n]
        return [(name, round(float(v), 4)) for name, v in pairs]


_predictor = CertificatePredictor()


def get_predictor():
    return _predictor


def build_indicators(features, fields, qr, metadata, has_text_layer):
    """
    Human-readable observations. These are simple rules that explain the result;
    they are NOT used by the model and they are NOT proof of anything.
    """
    items = []

    def add(level, text):
        items.append({"level": level, "text": text})

    if not has_text_layer and features["ocr_confidence"] < 60:
        add("warn", "Low OCR confidence - the text was hard to read (poor scan quality or unusual fonts).")
    if features["text_length"] < 80:
        add("warn", "Very little text was detected on the document.")
    missing = [label for key, label in [("certificate_id", "certificate ID"), ("date", "date"),
                                        ("institution", "institution name"), ("name", "holder name")]
               if not fields.get(key)]
    if missing:
        add("warn", "Not detected in the text: " + ", ".join(missing) + ".")
    if fields.get("certificate_id"):
        add("info", f"Certificate ID '{fields['certificate_id']}' was extracted - its pattern requires "
                    "verification with the issuer.")
    if features["blur_score"] < 80:
        add("warn", "Unusual image characteristics: the image looks blurry / low in sharpness.")
    if features["noise_level"] > 3:
        add("warn", "Unusual image characteristics: high noise or compression artefacts.")
    if features["width"] < 800 and features["height"] < 800:
        add("warn", "Low image resolution reduces the reliability of every check.")
    if not features["has_qr"]:
        add("info", "No QR code present (many genuine certificates do not have one).")
    elif qr.get("decoded"):
        add("info", "QR data was extracted but it has NOT been verified - check it with the issuer.")
    if metadata.get("editing_tool"):
        add("info", f"File metadata mentions '{metadata['editing_tool']}' (informational only).")
    if not items:
        add("info", "No notable irregular characteristics were found by the basic checks.")
    return items


def build_recommendation(prediction):
    if prediction == Config.LABEL_SUSPICIOUS:
        return ("Verify this certificate directly with the issuing institution or a trusted "
                "verification database before accepting it. This tool only flags patterns - it cannot "
                "prove that a document is forged.")
    return ("The document appears consistent with the patterns learned by the model, but final "
            "authenticity must still be confirmed with the issuing institution.")
