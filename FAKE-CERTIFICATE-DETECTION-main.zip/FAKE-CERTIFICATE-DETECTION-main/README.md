# CertCheck AI: Intelligent Fake Certificate & Document Tampering Detection

[![Python](https://img.shields.io/badge/Python-3.11%2B%20%7C%203.14-blue.svg)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Flask-3.1-black.svg)](https://flask.palletsprojects.com/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.35%2B-FF4B4B.svg)](https://streamlit.io/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.4%2B-orange.svg)](https://scikit-learn.org/)
[![OpenCV](https://img.shields.io/badge/OpenCV-5.0-green.svg)](https://opencv.org/)

An enterprise-grade, multi-modal digital forensics and machine learning system for detecting counterfeit academic certificates, degrees, and tampered documents.

---

## 🌟 Key Forensic Capabilities (Jury Highlights)

1. **Multi-Modal Forensics Pipeline:**
   - **Error Level Analysis (ELA):** Detects digital splicing, photoshopped names, and compression inconsistencies.
   - **High-Frequency Edge Mapping (Canny):** Identifies artificial boundary insertions.
   - **Structural Region Segmentation:** Segments text blocks, official seal/logo regions, and signature scribbles.
   - **Linguistic & OCR Extraction (Tesseract + NLP):** Extracts Candidate Name, Issuing Institution, Certificate ID, Course, Date, and Grade.
   - **Cross-Modal Consistency Verification:** Cross-references printed Certificate ID against 2D QR Code Matrix payload.
   - **Container EXIF & Metadata Forensics:** Flags tampering software signatures (Photoshop, Canva, GIMP, etc.).

2. **Machine Learning Architecture:**
   - **Classifier:** Random Forest Ensemble (200 de-correlated estimators).
   - **Engineered Feature Space:** 24 multi-modal numerical descriptors.
   - **Validation Accuracy:** 93.5% test accuracy with 5-fold stratified cross-validation (93.4%).
   - **Explainability:** Feature importance weighting & individual contribution breakdown.
   - **Trust Index:** 0–100 composite authenticity metric.

3. **Dual Deployment Modes:**
   - **Flask SPA Dashboard:** Interactive Single Page Application at `http://127.0.0.1:5000/`.
   - **Streamlit Web Application:** Deployable on Streamlit Community Cloud at `http://localhost:8501/`.

---

## 🚀 Quick Start & Running Locally

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Flask Single Page Web App (Port 5000)
```bash
python app.py
```
Open **[http://127.0.0.1:5000](http://127.0.0.1:5000)** in your browser.

### 3. Run Streamlit Application (Port 8501)
```bash
python -m streamlit run streamlit_app.py
```
Open **[http://localhost:8501](http://localhost:8501)** in your browser.

---

## ☁️ Deploying to Streamlit Community Cloud (Free 1-Click Cloud Hosting)

You can host this project on the web for free using Streamlit Community Cloud:

1. **Push your code to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "CertCheck AI deployment"
   git branch -M main
   git remote add origin https://github.com/<YOUR-USERNAME>/fake-certificate-detection.git
   git push -u origin main
   ```
2. **Deploy on Streamlit:**
   - Go to [share.streamlit.io](https://share.streamlit.io/) and log in with GitHub.
   - Click **"New App"**.
   - Select your repository, set Main file path to `streamlit_app.py`.
   - Click **"Deploy"**!

---

## 🔬 Multi-Modal Forensic Architecture

```mermaid
graph TD
    A[Certificate Document: Image or PDF] --> B[PyMuPDF 200 DPI Rendering / Image Normalization]
    
    B --> C1[Tesseract OCR & NLP Entity Extraction]
    B --> C2[Computer Vision & Error Level Analysis ELA]
    B --> C3[Morphological Layout Segmentation]
    B --> C4[QR Code 2D Matrix Decoder]
    B --> C5[EXIF / PDF Container Metadata]
    
    C1 --> D[24-Feature Telemetry Vector]
    C2 --> D
    C3 --> D
    C4 --> D
    C5 --> D
    
    C1 & C4 --> E[Cross-Modal Consistency Validator]
    
    D --> F[Random Forest Ensemble Classifier: 200 Trees]
    F --> G[Classification: Genuine-Likely vs Suspicious]
    E & F & C2 --> H[Trust Index Score: 0 - 100]
    
    G & H --> I[Interactive Forensic Dashboard & PDF Export]
```

---

## 🎓 Viva & Jury Defense Guide (Evaluation Q&A)

### Q1: Why choose Random Forest over a deep neural network (CNN/ResNet)?
> **Answer:** Random Forest works on explicit, interpretable, domain-engineered forensic features (OCR confidence, blur metric, ELA variance, noise level, structural region counts). Unlike deep learning black boxes, Random Forest provides exact feature importances, eliminates catastrophic overfitting on smaller document sets, and executes sub-100ms inference on standard CPUs without GPU overhead.

### Q2: How does Error Level Analysis (ELA) catch digital certificate forgery?
> **Answer:** JPEG compression operates on 8x8 DCT grid blocks. When a fraudulent name or certificate ID is spliced into an existing certificate, the modified region compresses at a different error rate than the unedited background. ELA visualizes and quantifies this discrepancy as high-contrast pixel differences.

### Q3: What is Cross-Modal Verification?
> **Answer:** Cross-modal verification checks whether data extracted from text (OCR modality) matches information stored inside the 2D barcode (QR code modality). If an attacker tampers with the candidate name or certificate ID in the visible document without altering the cryptographic QR payload, the system immediately flags the conflict.

---

## 📁 Repository Structure

```
fake_certificate_detection/
├── app.py                     # Flask Single Page Application & REST API
├── streamlit_app.py           # Streamlit Cloud-Ready Web Application
├── config.py                  # Central configuration
├── requirements.txt           # Python dependencies
├── database/
│   └── database.py            # SQLite local audit log
├── ml/
│   ├── dataset_generator.py   # Synthetic feature generator
│   ├── train_model.py         # Random Forest training & validation pipeline
│   ├── feature_extractor.py   # 24-feature extraction pipeline
│   ├── predictor.py           # Classifier inference & indicator heuristics
│   └── model/                 # Saved Random Forest model
├── services/
│   ├── analyzer.py            # End-to-end multi-modal forensic orchestrator
│   ├── image_service.py       # OpenCV preprocessing, ELA & layout segmentation
│   ├── ocr_service.py         # Tesseract OCR & regex entity parser
│   ├── qr_service.py          # Barcode decoding & URL validation
│   ├── metadata_service.py    # Container EXIF & tool tampering checks
│   └── sample_service.py      # Automated sample generator
├── static/
│   ├── css/style.css          # Modern dark/light glassmorphic stylesheet
│   ├── js/script.js           # Client-side SPA controller & Chart.js logic
│   └── samples/               # Built-in genuine & tampered samples
└── templates/
    ├── base.html              # Base layout with toast container & lightbox
    └── index.html             # Unified Single Page Application template
```

---

## ⚖️ Ethical & Educational Disclaimer

This software is developed for educational, academic, and demonstration purposes. Machine learning and image processing algorithms analyze statistical anomalies and cannot replace official institutional verification with authorized registrars.
