"""
SAFE demonstration dataset generator.

It creates ONLY numbers (feature records) - no certificates, no images, no forged
documents. The numbers are drawn from different statistical patterns for
"genuine" (label 1) and "suspicious" (label 0) records so that the ML pipeline can be
demonstrated. Replace this with a real, permission-based labelled dataset for any
serious use (see README).

Run:  python ml/dataset_generator.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config                       # noqa: E402
from ml.feature_extractor import FEATURE_NAMES  # noqa: E402


def generate_dataset(n_per_class=1000, seed=42, label_noise=0.04, save_path=None):
    rng = np.random.default_rng(seed)

    def normal(mean, sd, lo, hi, n):
        return np.clip(rng.normal(mean, sd, n), lo, hi)

    def flag(p, n):
        return (rng.random(n) < p).astype(int)

    def make_class(n, genuine):
        g = genuine
        text_length = normal(900 if g else 520, 330 if g else 380, 20, 3000, n)
        words_per_char = 1.0 / normal(6.2, 0.5, 4.5, 8.0, n)
        aspect = normal(1.40, 0.12, 0.6, 1.9, n) if g else normal(1.30, 0.35, 0.5, 2.0, n)
        width = np.where(aspect >= 1, normal(1800 if g else 1400, 350 if g else 500, 500, 2000, n),
                         normal(1400, 300, 500, 1800, n))
        height = width / aspect
        data = {
            "text_length": text_length.round(),
            "word_count": (text_length * words_per_char).round(),
            "digit_count": (text_length * normal(0.045 if g else 0.075, 0.02, 0, 0.3, n)).round(),
            "special_char_count": (text_length * normal(0.02 if g else 0.045, 0.012, 0, 0.2, n)).round(),
            "has_certificate_id": flag(0.88 if g else 0.50, n),
            "has_date": flag(0.92 if g else 0.65, n),
            "has_institution": flag(0.92 if g else 0.60, n),
            "has_name": flag(0.90 if g else 0.65, n),
            "has_course": flag(0.82 if g else 0.50, n),
            "ocr_confidence": normal(84 if g else 68, 7 if g else 13, 20, 99, n),
            "width": width.round(),
            "height": height.round(),
            "aspect_ratio": aspect,
            "brightness": normal(212 if g else 190, 20 if g else 38, 60, 255, n),
            "contrast": normal(62 if g else 52, 15 if g else 20, 10, 120, n),
            "edge_density": normal(0.06 if g else 0.09, 0.025 if g else 0.04, 0.002, 0.3, n),
            "blur_score": normal(700 if g else 250, 400 if g else 200, 5, 3000, n),
            "noise_level": normal(0.6 if g else 1.8, 0.5 if g else 1.2, 0.0, 12, n),
            "color_saturation": normal(45 if g else 55, 25 if g else 35, 0, 200, n),
            "text_density": normal(0.20 if g else 0.16, 0.07 if g else 0.09, 0.01, 0.8, n),
            "region_count": normal(22 if g else 16, 8 if g else 10, 1, 80, n).round(),
            "has_qr": flag(0.40 if g else 0.20, n),
            "has_logo_region": flag(0.80 if g else 0.45, n),
            "has_signature_region": flag(0.70 if g else 0.40, n),
        }
        frame = pd.DataFrame(data)[FEATURE_NAMES]
        frame["label"] = 1 if g else 0
        return frame

    df = pd.concat([make_class(n_per_class, True), make_class(n_per_class, False)], ignore_index=True)

    # Realistic data is never perfectly separable: flip a few labels.
    flip = rng.random(len(df)) < label_noise
    df.loc[flip, "label"] = 1 - df.loc[flip, "label"]

    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    for col in FEATURE_NAMES:
        df[col] = df[col].round(4)

    save_path = save_path or Config.DATASET_PATH
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    df.to_csv(save_path, index=False)
    return df


if __name__ == "__main__":
    frame = generate_dataset()
    print(f"Synthetic demo dataset created: {Config.DATASET_PATH}")
    print(f"Rows: {len(frame)} | Features: {len(FEATURE_NAMES)}")
    print("Label counts (0 = Suspicious, 1 = Genuine):")
    print(frame['label'].value_counts().sort_index().to_string())
    print("\nNOTE: this is synthetic numeric data for demonstrating the ML pipeline only.")
