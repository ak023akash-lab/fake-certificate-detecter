"""
Feature extraction pipeline.

The SAME function (extract_features) is used when the app predicts and when a real
dataset is built, so training and prediction always see identical features.
"""
import re
from collections import OrderedDict

# Order matters: the model is trained with exactly this column order.
FEATURE_NAMES = [
    # text features
    "text_length", "word_count", "digit_count", "special_char_count",
    "has_certificate_id", "has_date", "has_institution", "has_name", "has_course",
    "ocr_confidence",
    # image features
    "width", "height", "aspect_ratio", "brightness", "contrast",
    "edge_density", "blur_score", "noise_level", "color_saturation",
    # structural features
    "text_density", "region_count", "has_qr", "has_logo_region", "has_signature_region",
]

FEATURE_LABELS = {
    "text_length": "OCR text length", "word_count": "Number of words",
    "digit_count": "Number of digits", "special_char_count": "Special characters",
    "has_certificate_id": "Certificate ID found", "has_date": "Date found",
    "has_institution": "Institution found", "has_name": "Name found",
    "has_course": "Course found", "ocr_confidence": "OCR confidence",
    "width": "Image width (px)", "height": "Image height (px)",
    "aspect_ratio": "Aspect ratio", "brightness": "Mean brightness",
    "contrast": "Contrast", "edge_density": "Edge density",
    "blur_score": "Sharpness score", "noise_level": "Noise level",
    "color_saturation": "Colour saturation", "text_density": "Text density",
    "region_count": "Text regions", "has_qr": "QR code present",
    "has_logo_region": "Logo-like region", "has_signature_region": "Signature-like region",
}


def extract_features(image_info, text, ocr_confidence, fields, qr_detected):
    """
    image_info    : dictionary returned by image_service.analyze_image()
    text          : cleaned OCR (or PDF text-layer) text
    ocr_confidence: mean OCR confidence 0-100
    fields        : dictionary returned by ocr_service.extract_fields()
    qr_detected   : True / False
    """
    text = text or ""
    img = image_info["features"]
    special = len(re.findall(r"[^A-Za-z0-9\s]", text))

    values = {
        "text_length": len(text),
        "word_count": len(text.split()),
        "digit_count": sum(ch.isdigit() for ch in text),
        "special_char_count": special,
        "has_certificate_id": int(bool(fields.get("certificate_id"))),
        "has_date": int(bool(fields.get("date"))),
        "has_institution": int(bool(fields.get("institution"))),
        "has_name": int(bool(fields.get("name"))),
        "has_course": int(bool(fields.get("course"))),
        "ocr_confidence": round(float(ocr_confidence), 2),
        "has_qr": int(bool(qr_detected)),
    }
    values.update({k: img[k] for k in (
        "width", "height", "aspect_ratio", "brightness", "contrast", "edge_density",
        "blur_score", "noise_level", "color_saturation", "text_density", "region_count",
        "has_logo_region", "has_signature_region")})

    ordered = OrderedDict()
    for name in FEATURE_NAMES:
        value = values[name]
        ordered[name] = int(value) if isinstance(value, bool) else value
    return ordered
