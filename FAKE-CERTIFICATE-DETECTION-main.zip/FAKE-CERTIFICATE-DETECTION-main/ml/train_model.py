"""
Train the Random Forest model.

Usage:
    python ml/train_model.py                                   (uses the demo dataset)
    python ml/train_model.py --data dataset/real_features.csv  (uses your own dataset)
"""
import argparse
import json
import os
import sys
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score)
from sklearn.model_selection import cross_val_score, train_test_split

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config                       # noqa: E402
from ml.dataset_generator import generate_dataset  # noqa: E402
from ml.feature_extractor import FEATURE_NAMES  # noqa: E402


def _save_confusion_matrix_png(cm, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    fig, ax = plt.subplots(figsize=(4.2, 3.8))
    ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1], ["Suspicious", "Genuine"])
    ax.set_yticks([0, 1], ["Suspicious", "Genuine"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion matrix (test set)")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=14)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def train_model(data_path=None, model_path=None):
    data_path = data_path or Config.DATASET_PATH
    model_path = model_path or Config.MODEL_PATH
    using_default = os.path.abspath(data_path) == os.path.abspath(Config.DATASET_PATH)

    if not os.path.exists(data_path):
        if using_default:
            print("Demo dataset not found - generating it first...")
            generate_dataset()
        else:
            raise FileNotFoundError(f"Dataset not found: {data_path}")

    df = pd.read_csv(data_path)
    missing = [c for c in FEATURE_NAMES + ["label"] if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing columns: {missing}")
    df = df.dropna(subset=FEATURE_NAMES + ["label"])

    X, y = df[FEATURE_NAMES], df["label"].astype(int)

    # Split FIRST (stratified) so that the test data is never seen during training.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)

    model = RandomForestClassifier(
        n_estimators=200, max_depth=12, min_samples_leaf=3,
        class_weight="balanced", random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])
    cv_scores = cross_val_score(model, X_train, y_train, cv=5)  # CV on training data only

    metrics = {
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "precision": round(float(precision_score(y_test, y_pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, y_pred, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, y_pred, zero_division=0)), 4),
        "cv_accuracy_mean": round(float(np.mean(cv_scores)), 4),
        "cv_accuracy_std": round(float(np.std(cv_scores)), 4),
        "confusion_matrix": cm.tolist(),
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "n_features": len(FEATURE_NAMES),
        "dataset_type": "Synthetic demonstration dataset" if using_default else "User-supplied dataset",
        "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "feature_importances": {n: round(float(v), 4) for n, v in
                                sorted(zip(FEATURE_NAMES, model.feature_importances_),
                                       key=lambda t: t[1], reverse=True)},
    }

    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump({"model": model, "feature_names": FEATURE_NAMES}, model_path)
    with open(Config.METRICS_PATH, "w", encoding="utf-8") as fh:
        json.dump(metrics, fh, indent=2)
    _save_confusion_matrix_png(cm, os.path.join(Config.REPORTS_DIR, "confusion_matrix.png"))

    print("=" * 56)
    print(" MODEL TRAINING REPORT")
    print("=" * 56)
    print(f" Dataset        : {metrics['dataset_type']} ({len(df)} rows)")
    print(f" Train / Test   : {metrics['n_train']} / {metrics['n_test']}")
    print(f" Accuracy       : {metrics['accuracy'] * 100:.2f}%")
    print(f" Precision      : {metrics['precision'] * 100:.2f}%")
    print(f" Recall         : {metrics['recall'] * 100:.2f}%")
    print(f" F1-score       : {metrics['f1_score'] * 100:.2f}%")
    print(f" 5-fold CV acc. : {metrics['cv_accuracy_mean'] * 100:.2f}% (+/- {metrics['cv_accuracy_std'] * 100:.2f})")
    print("\n Confusion matrix (rows = actual, columns = predicted)")
    print("                  Pred:Suspicious   Pred:Genuine")
    print(f"  Actual:Suspicious   {cm[0][0]:>8}        {cm[0][1]:>8}")
    print(f"  Actual:Genuine      {cm[1][0]:>8}        {cm[1][1]:>8}")
    print("\n Classification report:")
    print(classification_report(y_test, y_pred, target_names=["Suspicious", "Genuine"], zero_division=0))
    print(" Top 5 important features:")
    for name, value in list(metrics["feature_importances"].items())[:5]:
        print(f"   - {name:<20} {value:.4f}")
    print(f"\n Model saved to : {model_path}")
    print(f" Reports saved  : {Config.REPORTS_DIR}")
    print("=" * 56)
    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train the certificate classifier")
    parser.add_argument("--data", help="Path to a CSV file with the feature columns + 'label'")
    args = parser.parse_args()
    train_model(args.data)
